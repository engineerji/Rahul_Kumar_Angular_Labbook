import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {
  employees:Array<Employee>=[];
  constructor() { }

  addEmployee(employee:Employee){
    this.employees.push(employee);
  }
  getEmployees(){
    return this.employees;
  }
}
