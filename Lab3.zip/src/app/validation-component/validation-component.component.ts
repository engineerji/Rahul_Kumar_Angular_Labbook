import { Component, OnInit } from '@angular/core';
import { Product } from '../product';

@Component({
  selector: 'app-validation-component',
  templateUrl: './validation-component.component.html',
  styleUrls: ['./validation-component.component.css']
})
export class ValidationComponentComponent implements OnInit {

  productModel = new Product("","","","","","");
  constructor() { 

  }

  ngOnInit(): void {
  }
  doAny(){
    alert(this.productModel.productId);
  }

}
