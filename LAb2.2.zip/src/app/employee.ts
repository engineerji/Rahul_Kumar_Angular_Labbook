export class Employee {
    empId:number;
    empName:string;
    empSal:number;
    empDept:string;
    empJoiningDate:string;

    constructor(empId:number,empName:string,empSal:number,empDept:string,empJoiningDate:string){
        this.empId=empId;
        this.empName=empName;
        this.empSal=empSal;
        this.empDept=empDept;
        this.empJoiningDate=empJoiningDate;
    }
}
