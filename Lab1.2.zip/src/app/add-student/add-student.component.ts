import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from '../employee-service.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {
  employees=[];
  employeeModel= new Employee(0,"",0,"");
  __service:EmployeeServiceService;
  emp = {
    name:"",
    id:0,
    salary:0,
    dept:""
  };
  constructor(__service:EmployeeServiceService) { 
    this.__service=__service;
  }

  ngOnInit(): void {
    this.employees=this.__service.getEmployees();
  }

  doAdd(){
   
    this.__service.addEmployee(this.employeeModel);
    console.log("done");

    alert(this.employeeModel.id+" "+this.employeeModel.name+" "+this.employeeModel.salary+" "+this.employeeModel.dept);
    this.employeeModel = new Employee(0,"",0,"");
  }
}

