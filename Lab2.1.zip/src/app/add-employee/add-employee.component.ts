import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { EmployeeServiceService } from '../employee-service.service';
import { Employee } from '../employee';
import { AllEmployeesComponent } from '../all-employees/all-employees.component';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  employeeModel= new Employee(0,"",0,"");
  __service:EmployeeServiceService;
  msg:AllEmployeesComponent;

  constructor(__service:EmployeeServiceService) { 
    this.__service=__service;
  }
  
  ngOnInit(): void {
  }

  doAdd(){
    this.__service.addEmployee(this.employeeModel);
   
    console.log("done");

    //alert(this.employeeModel.id+" "+this.employeeModel.name+" "+this.employeeModel.salary+" "+this.employeeModel.dept);
    this.employeeModel = new Employee(0,"",0,"");
    
    this.msg.setMessage(1);
  }

}
