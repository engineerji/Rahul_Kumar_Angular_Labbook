import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SortComponentComponent } from './sort-component.component';

describe('SortComponentComponent', () => {
  let component: SortComponentComponent;
  let fixture: ComponentFixture<SortComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SortComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SortComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
