export class SmartPhone {
}
