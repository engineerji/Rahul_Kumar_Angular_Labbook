export class Employee {
    id:number;
    name:string;
    salary:number;
    dept:string;

    constructor(id:number,name:string,salary:number,dept:string){
        this.id=id;
        this.name=name;
        this.salary=salary;
        this.dept=dept;
    }
}
