import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { EmployeeServiceService } from '../employee-service.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-all-employees',
  templateUrl: './all-employees.component.html',
  styleUrls: ['./all-employees.component.css']
})
export class AllEmployeesComponent implements OnInit {

  employees=[];
  updatableEmployee:Employee;
  __empService:EmployeeServiceService;
  constructor(__empService:EmployeeServiceService) {
    this.__empService=__empService;
   }
   @Output() mssg= new EventEmitter();
  ngOnInit(): void {
    this.employees=this.__empService.getEmployees();
    this.updatableEmployee= new Employee(0,"",0,"");
  }
  doUpdate(employee:Employee){
    this.updatableEmployee=employee;
    
    console.log(employee.name);
    console.log("@input");
  }
  doDelete(emp:Employee){
    let index = this.employees.indexOf(emp);
    for(let i=0;i<this.employees.length;i++){
      if(i===index){
        this.employees.splice(i,1);
      }
    }
    this.mssg.emit("DATA Deleted");
  }
  setMessage(ms:number){
    if(ms==1){
      alert("mil gaya");
      this.mssg.emit("DATA Added");
    }
    else{
      this.mssg.emit("DATA Updated");
    }
  }

}
