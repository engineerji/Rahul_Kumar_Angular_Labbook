import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {

  employees:Array<Employee>;
  constructor() { 
    this.employees=[
      {empId:1001,empName:'Rahul',empSal:9000,empDept:'Java',empJoiningDate:'6/12/2014'},
      {empId:1002,empName:'Vikas',empSal:11000,empDept:'ORAAPS',empJoiningDate:'6/12/2017'},
      {empId:1003,empName:'Uma',empSal:12000,empDept:'Java',empJoiningDate:'6/12/2010'},
      {empId:1004,empName:'Sachin',empSal:11500,empDept:'ORAAPS',empJoiningDate:'11/12/2017'},
      {empId:1005,empName:'Anmol',empSal:7000,empDept:'.Net',empJoiningDate:'1/1/2018'},
      {empId:1006,empName:'Vishal',empSal:17000,empDept:'BI',empJoiningDate:'9/12/2012'},
      {empId:1007,empName:'Rajita',empSal:21000,empDept:'BI',empJoiningDate:'6/7/2014'},
      {empId:1008,empName:'Neelima',empSal:81000,empDept:'Testing',empJoiningDate:'6/17/2015'},
      {empId:1009,empName:'Daya',empSal:1000,empDept:'Testing',empJoiningDate:'6/17/2016'},
    ];
  }
  getEmployees(){
    return this.employees;
  }
}
