import { Injectable, Output, EventEmitter } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {
  employees:Array<Employee>=[
    {id:1001,name:"Rahul",salary:9000,dept:"Java"},
    {id:1002,name:"Sachin",salary:19000,dept:"OraApps"},
    {id:1003,name:"Vikas",salary:29000,dept:"Java"}
  ];
  updatableAccounts : Employee = new Employee(0,'',0,'');
  constructor() { 
  }

  addEmployee(employee:Employee){
    this.employees.push(employee);
  }
  getEmployees(){
    return this.employees;
  }
  
  
  updateEmployee(updateEmp:Employee){
    this.updatableAccounts=updateEmp;
  }
}
