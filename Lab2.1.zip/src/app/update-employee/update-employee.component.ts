import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  @Input() updatableEmployee:Employee;
  __employeeService:EmployeeServiceService;
  constructor(__employeeService:EmployeeServiceService) { 
    this.__employeeService=__employeeService;
  }

  ngOnInit(): void {
  }

  doUpdate(){
    this.__employeeService.updateEmployee(this.updatableEmployee);
    this.updatableEmployee = new Employee(0,"",0,"");
  }

}
