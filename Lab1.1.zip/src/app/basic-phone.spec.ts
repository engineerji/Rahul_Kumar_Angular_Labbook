import { BasicPhone } from './basic-phone';

describe('BasicPhone', () => {
  it('should create an instance', () => {
    expect(new BasicPhone()).toBeTruthy();
  });
});
