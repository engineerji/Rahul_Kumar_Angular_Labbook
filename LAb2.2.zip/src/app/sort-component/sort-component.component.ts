import { Component, OnInit } from '@angular/core';
import { EmployeeServiceService } from '../employee-service.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-sort-component',
  templateUrl: './sort-component.component.html',
  styleUrls: ['./sort-component.component.css']
})
export class SortComponentComponent implements OnInit {

  employees:Array<Employee>;
  __empService:EmployeeServiceService;
  constructor(__empService:EmployeeServiceService) {
    this.__empService=__empService;
   }

  ngOnInit(): void {
    this.employees=this.__empService.getEmployees();

  }

  idSort(){
    let ar=this.employees;
    let temp:Employee;
    for(let i=0;i<ar.length-1;i++){
      for(let j=i+1;j<ar.length;j++){
        if(ar[i].empId>ar[j].empId){
          temp=ar[i];
          ar[i]=ar[j];
          ar[j]=temp;
        }
      }

    }
  }
  nameSort(){
    let ar=this.employees;
    let temp:Employee;
    for(let i=0;i<ar.length-1;i++){
      for(let j=i+1;j<ar.length;j++){
        if(ar[i].empName>ar[j].empName){
          temp=ar[i];
          ar[i]=ar[j];
          ar[j]=temp;
        }
      }

    }
  }
  salSort(){
    let ar=this.employees;
    let temp:Employee;
    for(let i=0;i<ar.length-1;i++){
      for(let j=i+1;j<ar.length;j++){
        if(ar[i].empSal>ar[j].empSal){
          temp=ar[i];
          ar[i]=ar[j];
          ar[j]=temp;
        }
      }

    }
  }
  deptSort(){
    let ar=this.employees;
    let temp:Employee;
    for(let i=0;i<ar.length-1;i++){
      for(let j=i+1;j<ar.length;j++){
        if(ar[i].empDept>ar[j].empDept){
          temp=ar[i];
          ar[i]=ar[j];
          ar[j]=temp;
        }
      }

    }
  }

}
